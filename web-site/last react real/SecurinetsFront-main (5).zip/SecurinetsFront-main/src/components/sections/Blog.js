import React from 'react'
import { Link } from "react-router-dom";


const Blog = ({ username, description, title, category }) => {

    return (


        /*   <div className="tiles-item reveal-from-middle" data-reveal-delay="200" > */
        <div className="tiles-item " data-reveal-delay="200">
            <div className="tiles-item-inner" >{username}
                <div className="testimonial-item-content" >
                    <p style={{ width: "200px", color: "red", wordWrap: "break-word" }}>
                        {description}
                    </p>

                </div>
                <div className="testimonial-item-footer text-xs mt-32 mb-0 has-top-divider">
                    <span className="testimonial-item-name text-color-high">{title}</span>
                    <Link to={`/Blogs/Category/${category}`} className="text-color-low">  CTF/ </Link>
                    <span className="testimonial-item-link"> qsfsqfsqsfqsfsfq</span>



                </div>
                <Link to={`/Blogs/${username}`} >see more </Link>
            </div>

        </div >


    )
}

export default Blog;
