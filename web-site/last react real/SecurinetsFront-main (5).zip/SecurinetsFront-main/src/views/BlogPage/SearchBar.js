import React from 'react'

export const SearchBar = () => {
    return (
        <div>
            <select >
                <option>
                    test
                </option>
            </select>
        </div>
    )
}
export default SearchBar