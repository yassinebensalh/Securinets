import React from 'react'
import axios from 'axios';
import { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { useParams } from 'react-router-dom'


export const BlogPage = () => {

    // extract id 
    const { id } = useParams();


    let isOwner;
    // store movies in state
    const [BlogContent, setBlogContent] = useState([]);

    const username = localStorage.getItem('username');






    // fetch movies
    useEffect(() => {
        axios.get(``)
            .then(res => setBlogContent([res.data]))
    }, [])
    BlogContent.owner === username ? isOwner = true : isOwner = false;


    return (
        <div className="container" style={{ marginTop: "25vh" }}>
            {!isOwner && <Link to={`/Blogs/Edit/${id}`} >Edit </Link>}

            <div dangerouslySetInnerHTML={{ __html: BlogContent }} />
        </div>
    )
}
export default BlogPage
